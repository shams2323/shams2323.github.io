$('document').ready(function() {
    //маска ввода для телефона
    $('input[name=phone]').mask("+7 (999) 999-99-99");
});